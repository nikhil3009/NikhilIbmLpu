package dao;

import model.Image;

public interface ImageDao 
{
	public void addImage(Image objimg);
	public void display(int imageId);
	public void delete(int imageId);
	public void update(int imageId, String imageUrl);
}
