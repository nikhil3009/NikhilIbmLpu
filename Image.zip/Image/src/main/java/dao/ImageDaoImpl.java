package dao;

import model.Image;

public class ImageDaoImpl implements ImageDao {

	public void addImage(Image objimg) {
		

	}

	public void display(int imageId) {
		// TODO Auto-generated method stub

	}

	public void delete(int imageId) {
		// TODO Auto-generated method stub

	}

	public void update(int imageId, String imageUrl) {
		// TODO Auto-generated method stub

	}

}
