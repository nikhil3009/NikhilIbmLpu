package com.example.model;

public class ToDo 
{
	private int id;
	private String name;
	private String endDate;
	public ToDo() {
		super();
	}
	public ToDo(int id, String name, String endDate) {
		super();
		this.id = id;
		this.name = name;
		this.endDate = endDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
}
