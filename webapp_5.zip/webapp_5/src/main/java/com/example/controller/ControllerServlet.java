package com.example.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.example.model.ToDo;


public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private List<String> errors;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doProcess(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doProcess(request, response);
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		errors=new ArrayList<String>();
		String name = request.getParameter("name").toString();
		int id =0;
		if(name.length()<8)
		{
			errors.add("invalid name.");
		}
		try {
	
			id= Integer.parseInt(request.getParameter("id").toString());
		} catch (Exception e) {
			errors.add("todo id must be numeric");
		}
	
		String endDate=request.getParameter("endDate").toString();
		if(endDate.length()<=0)
		{
			errors.add("completeed by field cant not be blank");
		}
			
		if(errors.isEmpty())
		{
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/java","root","Nikhil@7");  
				PreparedStatement ps=con.prepareStatement("insert into todo values(?,?,?)");  
				ps.setInt(1, id);
				ps.setString(2, name);
				ps.setString(3, endDate);
				ps.executeUpdate();
				con.close();
			}
			catch(Exception e)
			{ 
				System.out.println(e);
			}
			ToDo todo=new ToDo(id, name, endDate);
			request.setAttribute("todo", todo);//key and value pair
			RequestDispatcher view=request.getRequestDispatcher("success.jsp");
			view.forward(request, response);
		}
		else
		{
			
			request.setAttribute("error",errors);//key and value pair
			RequestDispatcher view=request.getRequestDispatcher("error.jsp");
			view.forward(request, response);
		}
		
		
	}

}
