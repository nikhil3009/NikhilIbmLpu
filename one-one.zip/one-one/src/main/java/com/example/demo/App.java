package com.example.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.example.entity.Project;
import com.example.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
       SessionFactory sf=new Configuration().configure().addAnnotatedClass(Project.class).addAnnotatedClass(Student.class).buildSessionFactory();
       Session ss=sf.openSession();
       Student objs=new Student("sai","nikhil","sainuikhil3009@gmail.com");
       Project objp=new Project(1,"elctrofight","complete");
       objs.setProject(objp);
       ss.beginTransaction();
       ss.save(objs);
       ss.getTransaction().commit();
    }
}
