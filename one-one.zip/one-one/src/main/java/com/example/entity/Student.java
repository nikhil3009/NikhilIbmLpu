package com.example.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Student1")
public class Student 
{
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Id
	@Column(name="sid")
	private String sid;
	@Column(name="firstname")
	private String name;
	@Column(name="lastname")
	private String lastname;
	@Column(name="email")
	private String  email;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pid")
	private Project project;
	public Student() {
		super();
	}
	public Student(String name, String lastname, String email) {
		super();
		this.name = name;
		this.lastname = lastname;
		this.email = email;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", lastname=" + lastname + ", email=" + email + "]";
	}
	

}
