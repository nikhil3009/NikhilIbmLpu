package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.InstructorDao;
import com.example.demo.model.Instructor;
@Service
public class InstructorServiceImpl implements InstructorService 
{
	@Autowired
	public InstructorDao instructorDao;
	@Override
	public List<Instructor> showAll() 
	{
		return instructorDao.showAll();
	}
	@Override
	public void createInstructor(Instructor i) 
	{
		instructorDao.createInstructor(i);
	}

	@Override
	public Instructor getById(int i) 
	{
		return instructorDao.getById(i);
	}

	@Override
	public void deleteById(Instructor i) 
	{
		instructorDao.deleteById(i);
	}
}
