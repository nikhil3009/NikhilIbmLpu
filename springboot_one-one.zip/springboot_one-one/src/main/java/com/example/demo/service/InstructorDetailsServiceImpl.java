package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.InstructorDetailsDao;
import com.example.demo.model.InstructorDetails;

@Service
public class InstructorDetailsServiceImpl implements InstructorDetailsService
{
	@Autowired
	InstructorDetailsDao instructorDetailsDao;

	@Override
	public List<InstructorDetails> showAll()
	{
		return instructorDetailsDao.showAll();
	}

	@Override
	public void createInstructor(InstructorDetails i) 
	{
		instructorDetailsDao.createInstructor(i);
		
	}

	@Override
	public InstructorDetails getById(int i) {
		
		return instructorDetailsDao.getById(i);
	}

	@Override
	public void deleteById(InstructorDetails i)
	{
		instructorDetailsDao.deleteById(i);
		
	}

}
