package com.example.demo.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Instructor;
@Repository
public class InstructorDaoImpl implements InstructorDao 
{
	@Autowired
	private EntityManager em;

	@Override
	public List<Instructor> showAll() 
	{
		Session ss=em.unwrap(Session.class);
		Query q=ss.createQuery("from Instructor i",Instructor.class);
		return q.getResultList();	
	}

	@Override
	public void createInstructor(Instructor i) 
	{
		Session ss=em.unwrap(Session.class);
		ss.getTransaction().begin();
		ss.saveOrUpdate(i);
		ss.getTransaction().commit();

	}

	@Override
	public Instructor getById(int i) 
	{
		Session ss=em.unwrap(Session.class);
		return ss.get(Instructor.class, i);	
	}

	@Override
	public void deleteById(Instructor i) 
	{
		Session ss=em.unwrap(Session.class);
		ss.getTransaction().begin();
		ss.delete(i);
		ss.getTransaction().commit();
		
		
		
		

	}

}
