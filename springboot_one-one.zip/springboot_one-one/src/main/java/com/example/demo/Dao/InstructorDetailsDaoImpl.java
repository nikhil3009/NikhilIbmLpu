package com.example.demo.Dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Instructor;
import com.example.demo.model.InstructorDetails;
@Repository
public class InstructorDetailsDaoImpl implements InstructorDetailsDao
{
	@Autowired
	EntityManager em;

	@Override
	public List<InstructorDetails> showAll() 
	{
		Session ss=em.unwrap(Session.class);
		Query q=ss.createQuery("from instructordetails i",InstructorDetails.class);
		return q.getResultList();
		
	}

	@Override
	public void createInstructor(InstructorDetails i) 
	{
		Instructor obj=i.getInstructor_id();
		obj.setDetails(i);
		Session ss=em.unwrap(Session.class);
		ss.getTransaction().begin();
		ss.saveOrUpdate(obj);
		ss.getTransaction().commit();
		
	}

	@Override
	public InstructorDetails getById(int i) 
	{
		Session ss=em.unwrap(Session.class);
		return ss.get(InstructorDetails.class, i);
	}

	@Override
	public void deleteById(InstructorDetails i)
	{
		Session ss=em.unwrap(Session.class);
		ss.getTransaction().begin();
		ss.delete(i);
		ss.getTransaction().commit();
	}
	
}
