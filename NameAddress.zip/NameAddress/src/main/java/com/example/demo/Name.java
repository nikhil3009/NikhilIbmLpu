package com.example.demo;
public interface Name
{
	public String displayName();
	public String displayAddress();

}