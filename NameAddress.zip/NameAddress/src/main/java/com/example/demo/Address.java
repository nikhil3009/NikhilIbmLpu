package com.example.demo;
public interface Address
{
	
	public String displayAddress();

}