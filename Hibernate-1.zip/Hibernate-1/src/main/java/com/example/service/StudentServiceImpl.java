package com.example.service;

import java.util.List;

import com.example.dao.StudentDaoImpl;
import com.example.domain.Student;

public class StudentServiceImpl implements StudentService
{
	private StudentDaoImpl obj;
	{
		obj=new StudentDaoImpl();
	}

	public Student createStudent(Student student) {
		// TODO Auto-generated method stub
		return obj.createStudent(student);
	}

	public List<Student> getAllStudent() {
		// TODO Auto-generated method stub
		return obj.getAllStudent();
	}

	public Student getStudentId(String id) {
		// TODO Auto-generated method stub
		return obj.getStudentId(id);
	}

}
