package com.example.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.example.domain.Student;
import com.example.factory.MyFactory;

public class StudentDaoImpl implements StudentDao
{
	private MyFactory mf;
	private SessionFactory sf;
	private Session ss;
	{
		mf=mf.getFactory();
		sf=mf.getSessionFactory();
		ss=sf.openSession();
	}

	public Student createStudent(Student student)
	{
		ss.getTransaction().begin();
		ss.save(student);
		ss.getTransaction().commit();
		return student;
	}

	public List<Student> getAllStudent()
	{
		List<Student> list=ss.createQuery("from student",Student.class).list();
		return list;
	}
	public Student getStudentId(String id)
	{
		return ss.get(Student.class, id);
	}

}
