package com.example.factory;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.example.domain.Student;

public class MyFactory 
{
	private SessionFactory sf;
	private  static MyFactory mf;
	private MyFactory()
	{
		
	}
	public SessionFactory getSessionFactory()
	{
		sf=new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
		return sf;
	}
	public static MyFactory getFactory()
	{
		if(mf==null)
		{
			mf=new MyFactory();
		}
		return mf;
	}
	{
		
	}

}
