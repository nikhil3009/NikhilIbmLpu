package com.example.demo;

import java.util.List;
import java.util.Scanner;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.example.domain.Student;
import com.example.service.StudentServiceImpl;


public class App {
	public static Scanner sc=new Scanner(System.in);
	public static StudentServiceImpl objSer=null;
	{
		objSer=new StudentServiceImpl();
	}
	public static void main(String[] args) 
	{

		//try {
			
			//SessionFactory factory=new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory();
			//Session session=factory.openSession();
		//	Student student=new Student();
			//student.setId(UUID.randomUUID().toString());
			//student.setFirstName("John");
			//student.setLastName("Doe");
			//student.setEmail("john@demo.com");
			//session.getTransaction().begin();
			//session.save(student);
			//session.getTransaction().commit();
			//System.out.println("One Item Saved Successfully..!");

		//} catch (Exception e) {

		//}
		int choice =0;
		while(choice !=3)
		{
			System.out.println("1.create student");
			System.out.println("2.Display all students");
			System.out.println("3.search student by id");
			System.out.println("enter your choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				{
					System.out.println("enter first name");
					String firstname=sc.next();
					System.out.println("enter the last name");
					String lastname=sc.next();
					System.out.println("enter the email");
					String email=sc.next();
					Student st=new Student();
					st.setFirstName(firstname);
					st.setLastName(lastname);
					st.setEmail(email);
					st.setId(UUID.randomUUID().toString());
					st=objSer.createStudent(st);
					System.out.println(st);
				}
				break;
			case 2:
				{
					List<Student> list=objSer.getAllStudent();
					for(Student s:list)
					{
						System.out.println(s);
					}
				}
				break;
			case 3:
				{
					System.out.println("enter student id");
					Student student=new Student();
					student=objSer.getStudentId(sc.next());
					if(student==null)
					{
						System.out.println("student not found");
					}
					else
					{
						System.out.println(student);
					}
				
				}
				break;
			default:
			{
				System.out.println("enter valid choice");
			}
			break;
			}
		}
	}
}
