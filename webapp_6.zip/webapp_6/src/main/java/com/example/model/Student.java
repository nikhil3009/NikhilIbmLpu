package com.example.model;

import java.util.LinkedHashMap;

public class Student 
{
	private String firstname;
	private String lastname;
	private String country;
	private LinkedHashMap<String,String> countryoptions;
	private String favoriteLanguage;
	private String[] operatingSystem;
	public Student()
	{
		countryoptions=new LinkedHashMap<String,String>();
		countryoptions.put("BR", "Brazil");
		countryoptions.put("FR", "France");
		countryoptions.put("DE", "Germany");
		countryoptions.put("IN", "India");
		countryoptions.put("US", "United states of america");
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public LinkedHashMap<String, String> getCountryoptions() {
		return countryoptions;
	}
	public void setCountryoptions(LinkedHashMap<String, String> countryoptions) {
		this.countryoptions = countryoptions;
	}
	public String getFavoriteLanguage() {
		return favoriteLanguage;
	}
	public void setFavoriteLanguage(String favoriteLanguage) {
		this.favoriteLanguage = favoriteLanguage;
	}
	public String[] getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String[] operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	

}
