package com.example.demo;

import java.util.UUID;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.Dao.AccountDao;
import com.example.demo.data.Account;
import com.example.demo.service.AccountService;

@SpringBootApplication
public class SpringbootAccountApplication implements CommandLineRunner{
	private AccountDao accountDao;
	private AccountService accountService;
	public SpringbootAccountApplication(AccountDao accountDao, AccountService accountService) 
	{
		super();
		this.accountDao = accountDao;
		this.accountService = accountService;
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAccountApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception 
	{
		accountDao.save(new Account(UUID.randomUUID().toString(), "Savings", 5000));
		accountDao.save(new Account(UUID.randomUUID().toString(), "Credit Card", 14000));
		accountDao.save(new Account(UUID.randomUUID().toString(), "current", 2000));
		System.out.println(accountService.getAllAccounts().toString());
		
	}
}
	
	