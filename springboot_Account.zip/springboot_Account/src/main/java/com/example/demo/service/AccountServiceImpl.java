package com.example.demo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Dao.AccountDao;
import com.example.demo.data.Account;
@Service(value = "accountService")
@EnableTransactionManagement
public class AccountServiceImpl implements AccountService
{
	private AccountDao accountDao;
	

	public AccountServiceImpl(AccountDao accountDao) 
	{
		super();
		this.accountDao = accountDao;
	}


	@Override
	@Transactional
	public ResponseEntity<Iterable<Account>> getAllAccounts() 
	{
		Iterable<Account> account=accountDao.findAll();
		return ResponseEntity.ok().body(account);
		
	}

}
