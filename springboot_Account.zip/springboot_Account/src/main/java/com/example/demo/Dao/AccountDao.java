package com.example.demo.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.example.demo.data.Account;
@Repository(value="accountDao")
@EnableTransactionManagement
public interface AccountDao extends CrudRepository<Account, Integer> 
{

}
