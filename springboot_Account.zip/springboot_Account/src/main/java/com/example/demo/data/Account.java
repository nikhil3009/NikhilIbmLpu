package com.example.demo.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="accountnum",nullable=false)
	private int aid;
	@Column(name="customerid")
	private String cid;
	@Column(name="account_type")
	private String accountType;
	@Column(name="balance")
	private double balance;
	public Account() {
		super();
	}
	public Account(String cid, String accountType, double balance) {
		super();
		this.cid = cid;
		this.accountType = accountType;
		this.balance = balance;
	}
	public int getAccountNum()
	{
		return aid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

}
