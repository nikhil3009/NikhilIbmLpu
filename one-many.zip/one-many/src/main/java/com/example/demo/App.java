package com.example.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.example.entity.Course;
import com.example.entity.Instructor;

public class App 
{
    public static void main( String[] args )
    {
         SessionFactory sf=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Instructor.class).addAnnotatedClass(Course.class).buildSessionFactory();
         Session ss=sf.openSession();
         Instructor obji=new Instructor("Nikhil","sainikhil3009@gmail.com");
         Course obj1=new Course("java full stack");
         Course obj2=new Course("pega");
         obji.addCourse(obj1);
         obji.addCourse(obj2);
         ss.beginTransaction();
         ss.save(obj1);
         ss.save(obj2);
         ss.getTransaction().commit();
         System.out.println("instructo nedd to teach" +obji);
         
    }
}
