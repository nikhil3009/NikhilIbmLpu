package com.example.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.domain.League;


public class ListLeague extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	private List<League> list=null;
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
		
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("title");
		String year=request.getParameter("year");
		int Year=Integer.parseInt(year);
		String season=request.getParameter("seasons");
		if(name.length()>7 && Year>2020)
		{
			RequestDispatcher dis=request.getRequestDispatcher("ok.html");
		}
		else
		{
			RequestDispatcher dis=request.getRequestDispatcher("notok.html");
		}
		
		
		
	}

}
