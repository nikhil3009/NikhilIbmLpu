package com.example.service;

import java.util.Collection;

import org.springframework.stereotype.Service;

import com.example.dao.EmployeeDaoImpl;
import com.example.entity.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService 
{
	
	private EmployeeDaoImpl obj;
	{
		obj=new EmployeeDaoImpl();
	}
	@Override
	public Employee createEmployee(Employee employee) {


		return obj.createEmployee(employee);
	}
	@Override
	public void removeEmployee(int id)
	{
		obj.removeEmployee(id);
		
	}
	@Override
	public Employee raiseEmployeeSalary(int id, int raise) 
	{
		return obj.raiseEmployeeSalary(id, raise);
	}
	@Override
	public Employee findEmployee(int id) 
	{
		
		return obj.findEmployee(id);
	}
	@Override
	public Collection<Employee> findAllEmployees()
	{
		return obj.findAllEmployees();
	}

}
