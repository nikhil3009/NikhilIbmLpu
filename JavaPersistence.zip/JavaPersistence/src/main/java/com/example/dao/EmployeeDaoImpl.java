package com.example.dao;

import java.util.Collection;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.entity.Employee;
@Repository
public class EmployeeDaoImpl implements EmployeeDao
{
	private SessionFactory sf;
	private EntityManagerFactory emf;
	private EntityManager em;
    @Autowired
	public EmployeeDaoImpl(SessionFactory sf) {
		super();
		this.sf = sf;
	}
    public EmployeeDaoImpl() {
		super();
	}
	@PostConstruct
    public void init()
    {
    	emf=sf.unwrap(SessionFactory.class);
    	em=emf.createEntityManager();
    			
    }

	@Override
	public Employee createEmployee(Employee employee) 
	{
		em.getTransaction().begin();
		em.persist(employee);
		em.getTransaction().commit();
		return employee;
		
	}
	@Override
	public void removeEmployee(int id)
	{
		Employee emp1=findEmployee(id);
		if(emp1==null)
		{
			System.out.println("deletion aborted");
		}
		else
		{
			em.getTransaction().begin();
			em.remove(emp1);
			em.getTransaction().commit();
			System.out.println("employee deleted"+ emp1);
		}
		
		
	}
	@Override
	public Employee raiseEmployeeSalary(int id, int raise)
	{
		Employee emp2=findEmployee(id);
		if(emp2==null)
		{
			System.out.println("employee not found");
			return null;
		}
		else
		{
			emp2.setSalary(emp2.getSalary()+ raise);
			em.getTransaction().begin();
			em.merge(emp2);
			em.getTransaction().commit();
			return emp2;
		}
		
	}
	@Override
	public Employee findEmployee(int id)
	{
		Employee emp=em.find(Employee.class, id);
		if(emp==null)
		{
			System.out.println("employe not found");
			return null;
		}
		else
		{
			return emp;
		}
		
	}
	@Override
	public Collection<Employee> findAllEmployees() {
		
		return em.createQuery("select e from Employee e", Employee.class).getResultList();
	}



}
