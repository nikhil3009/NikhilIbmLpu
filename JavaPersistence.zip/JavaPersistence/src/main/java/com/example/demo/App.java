package com.example.demo;

import java.util.Collection;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.entity.Employee;
import com.example.service.EmployeeService;
import com.example.service.EmployeeServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
    	EmployeeService service=context.getBean(EmployeeServiceImpl.class);
    	int choice=0;
    	Scanner sc=new Scanner(System.in);
    	while(choice!=6)
    	{
    		System.out.println("1.create employee");
    		System.out.println("2.delete employee");
    		System.out.println("3.Raise salary");
    		System.out.println("4.find employee by id");
    		System.out.println("5.find all employees");
    		System.out.println("enter your choice");
    		choice=sc.nextInt();
    		switch(choice)
    		{
    			case 1:
    				{
    					System.out.println("enter the name");
    					String name=sc.next();
    					System.out.println("enter the salary");
    					int salary=sc.nextInt();
    					Employee e=service.createEmployee(new Employee(name,salary));
    				}
    				break;
    			case 2:
    			{
    				System.out.println("enter the employee id");
    				int id=sc.nextInt();
    				service.removeEmployee(id);
    			}
    			break;
    			case 3:
    				{
    					System.out.println("enter employee id");
    					int id=sc.nextInt();
    					System.out.println("enter the salary how much should be raised");
    					int salary=sc.nextInt();
    					Employee e=service.raiseEmployeeSalary(id, salary);
    					if(e==null)
    					{
    						System.out.println("salary unable to raise");
    					}
    					else
    					{
    						System.out.println("salary raised"+e);
    					}
    				
    			}
    				break;
    			case 4:
    				{
    					System.out.println("enter the employee id");
    					int id=sc.nextInt();
    					Employee e=service.findEmployee(id);
    					if(e==null)
    					{
    						System.out.println("unable to fetch employee");
    					}
    					else
    					{
    						System.out.println("employee found"+e);
    					}
    				
    				}
    				break;
    			case 5:
    				{
    					Collection<Employee> c=service.findAllEmployees();
    					for(Employee e: c)
    					{
    						System.out.println(c);
    					}
    				}
    				break;
    			default:
    				System.out.println("enter valid choice");
    		
    		}
    		
    		
    	}
    	
    }
}
