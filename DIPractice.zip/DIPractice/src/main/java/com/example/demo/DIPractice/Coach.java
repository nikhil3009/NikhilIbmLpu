package com.example.demo.DIPractice;

public interface Coach 
{
	public String getDailyWorkout();
	public String getDailyFortune();
}
