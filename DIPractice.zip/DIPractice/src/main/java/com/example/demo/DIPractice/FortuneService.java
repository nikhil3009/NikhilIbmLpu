package com.example.demo.DIPractice;

public interface FortuneService 
{	
	public String getFortune();

}
